/**
 * dsh-bili-jar —— host 半端
 * ============================================================================
 * 规则（pool.mjs）负责把 200 多条压到 20 多条「技术上够格」的候选；
 * LLM（curator.mjs）负责**挑出 5 条并写理由** —— 也就是"帮你找好看视频"这件事本身。
 *
 * ⚠️ `apply(ctx, config)` 里拿到的 `config` 不是解析后的值（每个字段都是 `{}`），
 *    真实值必须走 `ctx.settings.describe()` 的 `value` 层。
 * ⚠️ 桌面版的 DSH 原生设置页不显示本插件的字段 ⇒ 配置面板做在罐子里，
 *    写到 `~/.dsh/bili-jar/config.json`，优先级最高。
 * ============================================================================
 */
import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync, appendFileSync, rmSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { homedir } from 'node:os'
import { inspect } from 'node:util'
import { loadHostDeps } from './lib/hostdeps.mjs'
import { buildPool, toCard } from './lib/pool.mjs'
import { writeReason, writeReasonCore, loadReasonCache, saveReasonCache, setUsageFile, lastError as llmError } from './lib/reasons.mjs'
import { todayUsage, migrateUsage } from './lib/usage.mjs'
import { writeStateDoc } from './lib/statefile.mjs'
import { curate } from './lib/curator.mjs'
import { adoptCookies, videoSubtitle, videoComments, loginStart, loginPoll, hasLogin } from './lib/bili.mjs'
import { qrDataUrl } from './lib/qr.mjs'
import { setLogFile, info as logInfo, warn as logWarn, tail as logTail } from './lib/log.mjs'

const PLUGIN_DIR = dirname(fileURLToPath(import.meta.url))

/** 可选头像：都是 assets/ 里的方图（从插画上裁的脸） */
const AVATAR_PRESETS = {
  sleep: { file: 'av-sleep.png', label: '睡觉' },
  tv: { file: 'av-tv.png', label: '看电视' },
  explore: { file: 'av-explore.png', label: '探险' },
  other: { file: 'av-other.png', label: '哦鲸鲸' },
}
const DEFAULT_AVATAR_PRESET = 'sleep'
const { z, notes: hostNotes } = await loadHostDeps()

export const name = 'dsh-bili-jar'
export const inject = ['webServer', 'settings']

const DEFAULTS = {
  axes: ['deepseek', '时政', '科技测评', '健身教程'],
  ups: [],
  fanMin: 0,
  fanMax: 0,
  minMinutes: 8,
  maxMinutes: 90,
  minPlay: 10000,
  mainCount: 5,
  showCharging: false,
  curatorOn: true,
  explainOn: true,
  reasonStyle: '像蓝发鲸鱼女仆在推荐：语气软、句子短、带一点俏皮，但不说废话，不堆感叹号。',
  apiBase: 'https://api.deepseek.com',
  apiKey: '',
  apiModel: 'deepseek-chat',
  /** self=只用我们搜的 / scroll=额外读 bili-scroll 的报告 / both=都读 */
  contentSource: 'self',
  /** 复用 bili-scroll 的 B站 登录（用于取 AI 字幕）。默认关，且不勾选绝不读那个文件 */
  useScrollLogin: false,
  /** 头像预设：sleep / tv / explore / other（custom = 自己上传的） */
  avatarPreset: 'sleep',
}

/**
 * ⚠️ 每个字段都要 `.extra('volatile', true)`，否则 DSH 的 settings.update() 会抛错。
 * ⚠️ 不要加会抛错的校验（.max/.min）：schema 不过 ⇒ entry 被拒收 ⇒ 整条插件不激活。
 */
export const Config = !z ? undefined : z.object({
  axes: z.array(z.string()).default(DEFAULTS.axes).extra('volatile', true),
  ups: z.array(z.string()).default([]).extra('volatile', true),
  fanMin: z.natural().default(0).extra('volatile', true),
  fanMax: z.natural().default(0).extra('volatile', true),
  minMinutes: z.natural().default(8).extra('volatile', true),
  maxMinutes: z.natural().default(90).extra('volatile', true),
  minPlay: z.natural().default(10000).extra('volatile', true),
  mainCount: z.natural().default(5).extra('volatile', true),
  showCharging: z.boolean().default(false).extra('volatile', true),
  /** 让模型当策展人：从候选里挑 5 条 + 写理由 */
  curatorOn: z.boolean().default(true).extra('volatile', true),
  /** 单独为某条写理由（不开启策展人时也能用） */
  explainOn: z.boolean().default(true).extra('volatile', true),
  /** 推荐理由的语气与风格 */
  reasonStyle: z.string().default('').extra('volatile', true),
})

const FEED_TTL = 30 * 60 * 1000

const unwrap = (v) => (v && typeof v === 'object' && 'value' in v ? v.value : v)

function toArr(v) {
  const x = unwrap(v)
  if (Array.isArray(x)) return x.map((s) => String(s).trim()).filter(Boolean)
  if (typeof x === 'string') return x.split(/[,，\n]/).map((s) => s.trim()).filter(Boolean)
  return []
}

function toNum(v, d) {
  const n = Number(unwrap(v))
  return Number.isFinite(n) ? n : d
}

function toBool(v) {
  return unwrap(v) === true
}

function toStr(v) {
  const x = unwrap(v)
  return typeof x === 'string' ? x : ''
}

function stateDirOf(ctx) {
  let dir = ''
  try {
    const p = ctx?.get?.('dshHomePath')
    if (typeof p === 'function') {
      const v = p('bili-jar')
      if (v) dir = String(v)
    } else if (typeof p === 'string' && p) {
      dir = join(p, 'bili-jar')
    }
  } catch { /* 兜底 */ }
  if (!dir) dir = join(process.env.DSH_HOME || join(homedir(), '.dsh'), 'bili-jar')
  mkdirSync(dir, { recursive: true })
  return dir
}

function sendJson(res, code, obj) {
  const body = JSON.stringify(obj)
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(body),
  })
  res.end(body)
}

function readJson(file, fallback) {
  try { return JSON.parse(readFileSync(file, 'utf8')) } catch { return fallback }
}

/**
 * 读 bili-scroll 的产物（纯只读）：日报里的 `### BV号` + 下一行的标题
 * 返回 [{bvid, title, source:'scroll'}]，最多 limit 条
 */
function readScrollSeeds(limit = 20) {
  const home = process.env.DSH_HOME || join(homedir(), '.dsh')
  const dirs = [join(home, 'bili-duty', 'out'), join(home, 'bili-duty', 'digest')]
  const out = []
  for (const dir of dirs) {
    let files = []
    try { files = readdirSync(dir).filter((f) => f.endsWith('.md')).sort().reverse().slice(0, 6) } catch { continue }
    for (const f of files) {
      let txt = ''
      try { txt = readFileSync(join(dir, f), 'utf8') } catch { continue }
      const lines = txt.split('\n')
      for (let i = 0; i < lines.length; i += 1) {
        const m = /^###\s*(BV[0-9A-Za-z]{10})/.exec(lines[i])
        if (!m) continue
        const next = String(lines[i + 1] || '').replace(/^[\s>*-]+/, '').split('|')[0].split('/')[0].trim()
        out.push({ bvid: m[1], title: next.slice(0, 80) || `（${m[1]}）`, source: 'scroll' })
        if (out.length >= limit) return out
      }
    }
  }
  return out
}

function readBody(req, limit = 64 * 1024) {  return new Promise((resolve) => {
    let size = 0
    const chunks = []
    req.on('data', (c) => {
      size += c.length
      if (size > limit) { resolve(''); req.destroy(); return }
      chunks.push(c)
    })
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))) } catch { resolve(null) }
    })
    req.on('error', () => resolve(null))
  })
}

export function apply(ctx, config) {
  const stateDir = stateDirOf(ctx)
  const logFile = join(stateDir, 'bili-jar.log')
  setLogFile(logFile)
  const log = (...a) => {
    try { console.log('[bili-jar]', ...a) } catch { /* 无控制台 */ }
    try { logInfo('console', a.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ')) } catch { /* 无所谓 */ }
  }

  const feedFile = join(stateDir, 'feed.json')
  const poolFile = join(stateDir, 'pool.json')
  const shownFile = join(stateDir, 'shown.json')
  const reasonsFile = join(stateDir, 'reasons.json')
  const overridesFile = join(stateDir, 'config.json')
  const feedbackFile = join(stateDir, 'feedback.jsonl')
  const laterFile = join(stateDir, 'later.json')
  // 重启会清掉内存里的池子/片单，磁盘上的 json 又没人愿意翻 —— 所以每次启动
  // 和每轮刷新之后，顺手写一份人眼能看的 STATE.md
  const refreshStateDoc = () => { try { writeStateDoc(stateDir) } catch { /* 写不出来不影响主流程 */ } }
  const usageFile = join(stateDir, 'usage.json')
  setUsageFile(usageFile)
  try {
    const m = migrateUsage(usageFile)
    if (m?.dropped) logInfo('usage:migrate', `去掉 ${m.dropped} 条重复的旧汇总，保留 ${m.kept} 条真实记录（备份 ${m.backup}）`)
    else if (m?.error) logWarn('usage:migrate-fail', m.error)
  } catch (e) { logWarn('usage:migrate-fail', String(e?.message ?? e)) }
  const version = (() => {
    try { return String(JSON.parse(readFileSync(join(PLUGIN_DIR, 'package.json'), 'utf8')).version || '') } catch { return '' }
  })()
  const startedAt = Date.now()
  let hits = 0

  let feedCache = (() => {
    const j = readJson(feedFile, null)
    return j && j.ts ? j : null
  })()
  let prevPool = readJson(poolFile, [])
  let lastShown = readJson(shownFile, [])
  let reasons = loadReasonCache(reasonsFile)
  /** 罐子里那份配置：优先级最高（原生设置页看不见这些字段，只能自己存） */
  let overrides = readJson(overridesFile, {})
  let building = null
  let explaining = null

  let rowCache = { at: 0, row: null }
  function settingsRow(fresh = false) {
    const t = Date.now()
    if (!fresh && t - rowCache.at < 3000) return rowCache.row
    let row = null
    try {
      const rows = ctx.settings?.describe?.() || []
      row = rows.find((r) => r?.value && 'axes' in r.value && 'ups' in r.value) || null
    } catch (e) { log(`读设置表单失败：${e?.message ?? e}`) }
    rowCache = { at: t, row }
    return row
  }

  function cfgNow() {
    const row = settingsRow()
    const src = row?.value && typeof row.value === 'object' ? row.value : config
    const c = (src && typeof src === 'object') ? src : {}
    const merged = { ...c, ...overrides }
    const axes = toArr(merged.axes)
    return {
      axes: axes.length ? axes : DEFAULTS.axes.slice(),
      ups: toArr(merged.ups),
      fanMin: toNum(merged.fanMin, 0),
      fanMax: toNum(merged.fanMax, 0),
      minMinutes: toNum(merged.minMinutes, 8),
      maxMinutes: toNum(merged.maxMinutes, 90),
      minPlay: toNum(merged.minPlay, 10000),
      mainCount: toNum(merged.mainCount, 5),
      showCharging: toBool(merged.showCharging),
      curatorOn: merged.curatorOn === undefined ? true : toBool(merged.curatorOn),
      explainOn: merged.explainOn === undefined ? true : toBool(merged.explainOn),
      reasonStyle: toStr(merged.reasonStyle) || DEFAULTS.reasonStyle,
      apiBase: toStr(merged.apiBase) || DEFAULTS.apiBase,
      apiKey: toStr(merged.apiKey),
      apiModel: toStr(merged.apiModel) || DEFAULTS.apiModel,
      contentSource: toStr(merged.contentSource) || DEFAULTS.contentSource,
      useScrollLogin: merged.useScrollLogin === true,
      avatarPreset: toStr(merged.avatarPreset) || DEFAULTS.avatarPreset,
    }
  }

  /**
   * 如果需要，接管 bili-scroll 的 B站 登录（只为了取 AI 字幕）。
   * ⚠️ 不勾选时**绝不**去读那个文件。
   */
  let adoptedAt = 0
  // 启动时优先用插件自己的凭证（扫码登录存下来的那份）
  try {
    const own = join(stateDir, 'credential.json')
    if (existsSync(own)) {
      const n = adoptCookies(JSON.parse(readFileSync(own, 'utf8')))
      if (n) logInfo('login:own', `${n} 个字段（插件自己的凭证）`)
    }
  } catch { /* 没有就算了 */ }

  function maybeAdoptLogin(cfg) {
    if (!cfg.useScrollLogin) return false
    if (Date.now() - adoptedAt < 10 * 60 * 1000) return true
    const home = process.env.DSH_HOME || join(homedir(), '.dsh')
    const f = join(home, 'bili-duty', 'bili_credential.json')
    if (!existsSync(f)) { logWarn('login:missing', f); return false }
    try {
      const cred = JSON.parse(readFileSync(f, 'utf8'))
      const n = adoptCookies(cred)
      adoptedAt = Date.now()
      logInfo('login:adopted', `${n} 个 cookie 字段（来自 bili-scroll）`)
      return n > 0
    } catch (e) { logWarn('login:fail', String(e?.message ?? e)); return false }
  }

  /**
   * 用真实内容重写推荐语：先取字幕，没有就退到热评。
   * 一次调用写 5 条，不逐条问。
   */
  async function enrichReasons(picks, cfg) {
    const got = []
    for (const p of picks) {
      let content = ''
      const sub = await videoSubtitle(p.bvid)
      if (sub.ok) content = sub.text
      else {
        const cm = await videoComments(p.bvid, 20)
        if (cm.ok) content = cm.text
      }
      logInfo('content:fetch', `${p.bvid} ${content ? content.length + ' 字' : '无内容'}`)
      got.push({ ...p, content })
    }
    const usable = got.filter((x) => x.content)
    if (!usable.length) return picks

    const system = [
      '你在替一个人写「这条视频为什么值得看」的一句话推荐语。',
      '下面给了你视频的真实内容（字幕或评论摘录），**依据内容写**，不要依据任何数据。',
      '🔴 不许出现任何数字（播放量、点赞率、收藏率、投币率都不行）。',
      '40–70 字，口语，具体：讲了什么、怎么讲的、适合什么时候看。不要用「这条视频」开头。',
      cfg.reasonStyle ? `语气与风格：${cfg.reasonStyle}` : '',
      '只输出 JSON 数组：[{"bvid":"BV...","why":"..."}]，不要代码块。',
    ].filter(Boolean).join('\n')
    const user = usable.map((x, i) => `${i + 1}. ${x.bvid} 《${x.title}》\n内容：${x.content.slice(0, 900)}`).join('\n\n')

    const text = await writeReasonCore(ctx, {
      system, user, maxTokens: 900, timeoutMs: 60000,
      api: { base: cfg.apiBase, key: cfg.apiKey, model: cfg.apiModel },
    })
    if (!text) { logWarn('content:llm-fail', llmError.msg || '空'); return picks }
    let arr = null
    try { const m = text.match(/\[[\s\S]*\]/); arr = JSON.parse(m ? m[0] : text) } catch { arr = null }
    if (!Array.isArray(arr)) { logWarn('content:parse-fail', text.slice(0, 80)); return picks }
    const byBvid = new Map(arr.map((x) => [String(x?.bvid || ''), String(x?.why || '').trim()]))
    return picks.map((p) => (byBvid.get(p.bvid) ? { ...p, why: byBvid.get(p.bvid).slice(0, 160) } : p))
  }

  async function getFeed(force) {
    const fresh = feedCache && Date.now() - feedCache.ts < FEED_TTL
    if (!force && fresh) return { ...feedCache, cached: true }
    if (building) return building
    building = (async () => {
      try {
        const t0 = Date.now()
        const cfg = cfgNow()
        maybeAdoptLogin(cfg)
        const exclude = force ? lastShown : []
        const r = await buildPool({ ...cfg, exclude }, (m) => log(m), prevPool)
        logInfo('feed:built', JSON.stringify(r.stats || {}))
        const out = { ...r, tookMs: Date.now() - t0, cached: false, excluded: exclude.length }
        feedCache = out
        lastShown = (r.main || []).map((c) => c.bvid)
        try { writeFileSync(shownFile, JSON.stringify(lastShown), 'utf8') } catch { /* 无所谓 */ }
        if (Array.isArray(r.pool)) {
          prevPool = r.pool
          try { writeFileSync(poolFile, JSON.stringify(prevPool), 'utf8') } catch (e) { log(`pool 落盘失败：${e?.message ?? e}`) }
        }
        try { writeFileSync(feedFile, JSON.stringify(out), 'utf8') } catch (e) { log(`feed 落盘失败：${e?.message ?? e}`) }
        refreshStateDoc()

        // ⭐ 策展人：规则给候选，模型挑 5 条并写理由
        // ⭐ 内容源：额外把 bili-scroll 报告里挑过的视频并进候选
        let shortlist = r.shortlist || []
        let seeded = 0
        if (cfg.contentSource === 'scroll' || cfg.contentSource === 'both') {
          const seeds = readScrollSeeds()
          const have = new Set(shortlist.map((x) => x.bvid))
          const add = seeds.filter((s) => !have.has(s.bvid)).map((s) => ({
            bvid: s.bvid, title: s.title, author: '', duration: 0, pubdate: Math.floor(Date.now() / 1000),
            play: 0, tags: [], typeName: '', pct: {}, source: 'scroll',
            reasons: ['来自 bili-scroll 的报告'],
          }))
          seeded = add.length
          shortlist = cfg.contentSource === 'both' ? [...shortlist, ...add] : add.length ? add : shortlist
          if (seeded) logInfo('seed:scroll', `${seeded} 条 / 模式=${cfg.contentSource}`)
        }

        if (cfg.curatorOn && shortlist.length) {
          const t1 = Date.now()
          const c = await curate(ctx, shortlist, cfg.reasonStyle, {
            pick: cfg.mainCount,
            api: { base: cfg.apiBase, key: cfg.apiKey, model: cfg.apiModel },
          })
          if (c.ok) {
            const byBvid = new Map(shortlist.map((x) => [x.bvid, x]))
            const curated = c.picks.map((p, i) => ({ ...byBvid.get(p.bvid), why: p.why, rank: i + 1 }))
            const enriched = await enrichReasons(curated, cfg)
            feedCache = { ...out, main: enriched, curated: true, curatorMs: Date.now() - t1 }
            logInfo('curate:ok', `${curated.length} 条 / ${Date.now() - t1}ms`)
            for (const p of c.picks) reasons[p.bvid] = { text: p.why, at: Date.now() }
            saveReasonCache(reasonsFile, reasons)
            try { writeFileSync(feedFile, JSON.stringify(feedCache), 'utf8') } catch { /* 无所谓 */ }
            refreshStateDoc()
            return feedCache
          }
          log(`策展失败，退回规则片单：${c.note}`)
          logWarn('curate:fail', String(c.note || '未知'))
          feedCache = { ...out, curated: false, curatorNote: c.note }
          refreshStateDoc()
          return feedCache
        }
        return out
      } catch (e) {
        log(`建池失败：${e?.message ?? e}`)
        if (feedCache) return { ...feedCache, cached: true, error: String(e?.message ?? e) }
        return { ok: false, error: String(e?.message ?? e), main: [], up: [], stats: {} }
      } finally {
        building = null
      }
    })()
    return building
  }

  /** 给当前这批补理由（没走策展人时用） */
  async function getReasons(force) {
    if (explaining) return explaining
    explaining = (async () => {
      const cfg = cfgNow()
      const items = feedCache?.main || []
      const out = {}
      let generated = 0
      for (const it of items) {
        if (it.why) { out[it.bvid] = it.why; continue }
        const hit = reasons[it.bvid]
        if (hit?.text && !force) { out[it.bvid] = hit.text; continue }
        if (generated >= 6) break
        const text = await writeReason(ctx, it, cfg.reasonStyle, {
          api: { base: cfg.apiBase, key: cfg.apiKey, model: cfg.apiModel },
        })
        if (text) {
          reasons[it.bvid] = { text, at: Date.now() }
          out[it.bvid] = text
          generated += 1
        }
      }
      if (generated) saveReasonCache(reasonsFile, reasons)
      return { ok: true, reasons: out, generated, style: cfg.reasonStyle }
    })().finally(() => { explaining = null })
    return explaining
  }

  const handle = async (req, res, url) => {
    const p = url.pathname.replace(/^\/api\/bili-jar/, '') || '/'

    if (req.method === 'GET' && p === '/ping') {
      hits += 1
      return sendJson(res, 200, {
        ok: true, plugin: name, version,
        uptimeMs: Date.now() - startedAt, hits,
        stateDir, hostNotes,
        poolSize: Array.isArray(prevPool) ? prevPool.length : 0,
        feed: feedCache ? { ts: feedCache.ts, main: feedCache.main?.length ?? 0, curated: Boolean(feedCache.curated) } : null,
      })
    }

    if (req.method === 'GET' && p === '/state') {
      const c = cfgNow()
      const key = c.apiKey || ''
      // 🔒 永远不把完整 key 递到浏览器：只给掩码
      const masked = key ? `sk-••••${key.slice(-4)}` : ''
      return sendJson(res, 200, {
        ok: true,
        stateDir,
        config: { ...c, apiKey: '' },
        apiKeySet: Boolean(key),
        apiKeyMasked: masked,
        feedTs: feedCache?.ts ?? null,
        poolSize: prevPool.length,
        usage: todayUsage(usageFile),
      })
    }

    if (req.method === 'POST' && p === '/config') {
      const body = await readBody(req)
      if (!body || typeof body !== 'object') return sendJson(res, 400, { ok: false, error: 'body 不是 JSON' })
      const allow = Object.keys(DEFAULTS)
      for (const [k, v] of Object.entries(body)) if (allow.includes(k)) overrides[k] = v
      try { writeFileSync(overridesFile, JSON.stringify(overrides), 'utf8') } catch (e) { log(`配置落盘失败：${e?.message ?? e}`) }
      return sendJson(res, 200, { ok: true, config: cfgNow(), overrides })
    }

    /* ── 语气预设：存的是"说话什么样"，不是整套配置 ──────────────────
     * 存在 config.json 的 `stylePresets`（名字 → 风格正文）。
     * 前端「导入 .md」读出来的文字也走这里，一键落成预设。 */
    if (req.method === 'GET' && p === '/style') {
      return sendJson(res, 200, { ok: true, presets: overrides.stylePresets || {}, current: String(cfgNow().reasonStyle || '') })
    }

    if (req.method === 'POST' && p === '/style') {
      const body = await readBody(req)
      const action = String(body?.action || 'save')
      const name = String(body?.name || '').trim().slice(0, 40)
      const presets = { ...(overrides.stylePresets || {}) }

      if (action === 'save' || action === 'import') {
        if (!name) return sendJson(res, 400, { ok: false, error: '预设得有个名字' })
        const text = String(body?.text || '').trim()
        if (!text) return sendJson(res, 400, { ok: false, error: '内容不能为空' })
        if (text.length > 8000) return sendJson(res, 400, { ok: false, error: '太长了（上限 8000 字）' })
        presets[name] = text
        overrides = { ...overrides, stylePresets: presets }
        try { writeFileSync(overridesFile, JSON.stringify(overrides), 'utf8') } catch { /* 下一句会报 */ }
        logInfo(action === 'import' ? 'style:import' : 'style:save', `${name}（${text.length} 字）`)
        return sendJson(res, 200, { ok: true, presets })
      }

      if (action === 'apply') {
        if (!presets[name]) return sendJson(res, 404, { ok: false, error: `没有这个预设：${name}` })
        overrides = { ...overrides, reasonStyle: presets[name] }
        try { writeFileSync(overridesFile, JSON.stringify(overrides), 'utf8') } catch { /* 同上 */ }
        logInfo('style:apply', name)
        return sendJson(res, 200, { ok: true, presets, text: presets[name] })
      }

      if (action === 'delete') {
        delete presets[name]
        overrides = { ...overrides, stylePresets: presets }
        try { writeFileSync(overridesFile, JSON.stringify(overrides), 'utf8') } catch { /* 同上 */ }
        return sendJson(res, 200, { ok: true, presets })
      }

      return sendJson(res, 400, { ok: false, error: `不认识的动作：${action}` })
    }

    /* ── 插画（豆包画的那三张）───────────────────────────────────────── */
    if (req.method === 'GET' && p === '/art') {
      const f = String(url.searchParams.get('f') || 'closed')
      const map = {
        closed: 'jar-closed.png', active: 'jar-active.png', face: 'face.png',
        'walk-a': 'walk-a.png', 'walk-b': 'walk-b.png',
      }
      const file = map[f]
      if (!file) return sendJson(res, 404, { ok: false, error: '没有这张图' })
      try {
        const buf = readFileSync(join(PLUGIN_DIR, 'assets', file))
        res.writeHead(200, { 'content-type': 'image/png', 'cache-control': 'public, max-age=86400' })
        return res.end(buf)
      } catch (e) { return sendJson(res, 404, { ok: false, error: String(e?.message ?? e) }) }
    }

    /* ── 头像：换成自己的 ──────────────────────────────────────────────── */
    /** 选一个内置头像。选完把上传过的那张删掉，否则它永远盖住预设。 */
    if (req.method === 'POST' && p === '/avatar/preset') {
      const body = await readBody(req)
      const name = String(body?.name || '')
      if (!AVATAR_PRESETS[name]) return sendJson(res, 400, { ok: false, error: `没有这个预设：${name}` })
      overrides = { ...overrides, avatarPreset: name }
      try { writeFileSync(overridesFile, JSON.stringify(overrides), 'utf8') } catch { /* 落盘失败不影响本次 */ }
      try { if (existsSync(join(stateDir, 'avatar.png'))) rmSync(join(stateDir, 'avatar.png')) } catch { /* 删不掉算了 */ }
      logInfo('avatar:preset', `${name}（${AVATAR_PRESETS[name].label}）`)
      return sendJson(res, 200, { ok: true, preset: name })
    }

    if (req.method === 'POST' && p === '/avatar') {
      const body = await readBody(req)
      const dataUrl = String(body?.dataUrl || '')
      const m = /^data:image\/(png|jpeg|jpg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl)
      if (!m) return sendJson(res, 400, { ok: false, error: '只认 png / jpeg / webp 的 base64' })
      let buf
      try { buf = Buffer.from(m[2], 'base64') } catch { return sendJson(res, 400, { ok: false, error: 'base64 解不开' }) }
      if (buf.length > 3 * 1024 * 1024) return sendJson(res, 400, { ok: false, error: '图太大了（上限 3 MB）' })
      try {
        mkdirSync(stateDir, { recursive: true })
        writeFileSync(join(stateDir, 'avatar.png'), buf)
        overrides = { ...overrides, avatarPreset: 'custom' }
        logInfo('avatar:set', `${Math.round(buf.length / 1024)} KB`)
        return sendJson(res, 200, { ok: true, uploadAt: Date.now() })
      } catch (e) { return sendJson(res, 500, { ok: false, error: String(e?.message ?? e) }) }
    }

    if (req.method === 'DELETE' && p === '/avatar') {
      try { if (existsSync(join(stateDir, 'avatar.png'))) rmSync(join(stateDir, 'avatar.png')) } catch (e) {
        return sendJson(res, 500, { ok: false, error: String(e?.message ?? e) })
      }
      logInfo('avatar:reset', '恢复默认头像')
      return sendJson(res, 200, { ok: true })
    }

    if (req.method === 'GET' && p === '/debug') {
      const safe = (fn, dflt) => { try { return fn() } catch (e) { return `ERR: ${e?.message ?? e}` } }
      let rows = safe(() => ctx.settings?.describe?.() || [], [])
      // 🔒 调试接口也不许把完整 key 递出去
      const dcfg = cfgNow()
      const maskKey = (k) => (k ? `sk-••••${String(k).slice(-4)}` : '')
      const dOver = { ...overrides }
      if (dOver.apiKey !== undefined) dOver.apiKey = maskKey(dOver.apiKey)
      return sendJson(res, 200, {
        ok: true,
        rowFound: Boolean(safe(() => settingsRow(true), null)),
        rowsCount: Array.isArray(rows) ? rows.length : String(rows).slice(0, 120),
        cfg: { ...dcfg, apiKey: maskKey(dcfg.apiKey) },
        overrides: dOver,
        poolSize: prevPool.length,
        llm: Boolean(safe(() => ctx.llm || ctx.get?.('llm'), null)),
        llmError: llmError.msg,
        usage: todayUsage(usageFile),
      })
    }

    if (req.method === 'GET' && p === '/log') {
      const n = Math.min(300, Number(url.searchParams.get('n')) || 100)
      return sendJson(res, 200, { ok: true, file: logFile, lines: logTail(n) })
    }

    // B站 扫码登录（插件自己的，不依赖 bili-scroll）
    if (req.method === 'GET' && p === '/login/start') {
      const r = await loginStart()
      if (r.ok) {
        // 自己画码（见 lib/qr.mjs）：SVG 内联成 data URL，前端一个 <img> 就够
        try { r.qr = qrDataUrl(r.url) } catch (e) { r.qrError = String(e?.message ?? e) }
        logInfo('login:start', r.qr ? '已生成二维码（SVG）' : `出码但没画出来：${r.qrError || ''}`)
      } else logWarn('login:start-fail', r.error || '')
      return sendJson(res, 200, r)
    }

    if (req.method === 'GET' && p === '/login/poll') {
      const key = url.searchParams.get('key') || ''
      if (!key) return sendJson(res, 400, { ok: false, error: '缺 key' })
      const r = await loginPoll(key)
      if (r.state === 'ok' && r.credential) {
        try {
          writeFileSync(join(stateDir, 'credential.json'), JSON.stringify(r.credential), 'utf8')
          adoptCookies(r.credential)
          adoptedAt = Date.now()
          logInfo('login:ok', '凭证已保存到插件家目录')
        } catch (e) { logWarn('login:save-fail', String(e?.message ?? e)) }
      }
      return sendJson(res, 200, { ok: r.ok, state: r.state, message: r.message || '', hasCredential: Boolean(r.credential) })
    }

    if (req.method === 'GET' && p === '/login/status') {
      return sendJson(res, 200, { ok: true, loggedIn: hasLogin(), ownCredential: existsSync(join(stateDir, 'credential.json')) })
    }

    // 赞 / 踩：只记本地，绝不落到 B站 账号
    if (req.method === 'POST' && p === '/feedback') {
      const body = await readBody(req)
      const bvid = String(body?.bvid || '').trim()
      const action = String(body?.action || '').trim()
      if (!bvid || !['like', 'dislike'].includes(action)) {
        return sendJson(res, 400, { ok: false, error: '要 {bvid, action: like|dislike}' })
      }
      const item = [...(feedCache?.main || []), ...(feedCache?.up || [])].find((x) => x.bvid === bvid) || {}
      const row = { ts: Date.now(), bvid, action, axis: item.axis || '', sub: item.sub || '', tags: (item.tags || []).slice(0, 6) }
      try { appendFileSync(feedbackFile, JSON.stringify(row) + '\n', 'utf8') } catch (e) { logWarn('feedback:write', String(e?.message ?? e)) }
      logInfo('feedback', `${action} ${bvid}`)
      return sendJson(res, 200, { ok: true, row })
    }

    // 稍后看：落盘，不再只存在浏览器
    if (req.method === 'GET' && p === '/later') {
      return sendJson(res, 200, { ok: true, items: readJson(laterFile, []) })
    }
    if (req.method === 'POST' && p === '/later') {
      const body = await readBody(req)
      const bvid = String(body?.bvid || '').trim()
      if (!bvid) return sendJson(res, 400, { ok: false, error: '要 bvid' })
      let list = readJson(laterFile, [])
      if (body.action === 'remove') list = list.filter((x) => x.bvid !== bvid)
      else if (!list.some((x) => x.bvid === bvid)) {
        const item = [...(feedCache?.main || []), ...(feedCache?.up || [])].find((x) => x.bvid === bvid) || body.item || { bvid }
        list = [{ bvid, title: item.title || '', author: item.author || '', durationText: item.durationText || '', url: item.url || `https://www.bilibili.com/video/${bvid}`, addedAt: Date.now() }, ...list].slice(0, 100)
      }
      try { writeFileSync(laterFile, JSON.stringify(list), 'utf8') } catch (e) { logWarn('later:write', String(e?.message ?? e)) }
      return sendJson(res, 200, { ok: true, items: list })
    }

    if (req.method === 'GET' && p === '/feed') {
      const force = url.searchParams.get('refresh') === '1'
      const r = await getFeed(force)
      return sendJson(res, 200, r)
    }

    /**
     * 「更多电子榨菜」：**不重新搜**，直接从上一轮留下的池子里再捞几条。
     * 理由先查磁盘缓存（reasons.json），查不到才叫模型 —— 所以关掉再打开、
     * 点这个按钮，上次写过的推荐语还能接着用，不用重花钱。
     */
    if (req.method === 'POST' && p === '/more') {
      const body = await readBody(req)
      const n = Math.min(5, Math.max(1, Number(body?.n) || 3))
      const f = feedCache
      if (!f || !Array.isArray(f.main) || !f.main.length) return sendJson(res, 200, { ok: false, error: '还没有片单，先刷一批' })
      if (f.main.length >= 30) return sendJson(res, 200, { ok: false, error: '已经 30 条了，先看一阵子吧；想换就点「换一批」' })

      const have = new Set(f.main.map((x) => x.bvid))
      // 先决赛圈（本来就是按分数排好的），再整个池子 —— 池子没分数，按互动率排
      const rateOf = (x) => (x.pct?.coin || 0) * 2 + (x.pct?.fav || 0) * 2 + (x.pct?.like || 0)
      const seen = new Set()
      const take = (x) => {
        if (!x?.bvid || have.has(x.bvid) || seen.has(x.bvid)) return false
        seen.add(x.bvid)
        return true
      }
      const queue = [
        ...(f.shortlist || []).filter(take),
        ...(f.pool || []).map((x) => toCard(x)).sort((a, b) => rateOf(b) - rateOf(a)).filter(take),
      ]
      if (!queue.length) return sendJson(res, 200, { ok: false, error: '池子掏空了 —— 点「换一批」才会去搜新的' })

      const cur = cfgNow()
      const batch = queue.slice(0, n)
      const whyOf = new Map()
      const need = []
      for (const it of batch) {
        const cached = reasons[it.bvid]?.text
        if (cached) whyOf.set(it.bvid, cached)
        else need.push(it)
      }

      let note = ''
      if (need.length && cur.curatorOn) {
        const c = await curate(ctx, need, cur.reasonStyle, {
          pick: need.length,
          api: { base: cur.apiBase, key: cur.apiKey, model: cur.apiModel },
          kind: 'more',
        })
        if (c.ok) {
          for (const pk of c.picks) { whyOf.set(pk.bvid, pk.why); reasons[pk.bvid] = { text: pk.why, at: Date.now() } }
          saveReasonCache(reasonsFile, reasons)
        } else note = String(c.note || '模型没写成')
      }

      const added = batch.filter((it) => whyOf.has(it.bvid)).map((it) => ({ ...it, why: whyOf.get(it.bvid), more: true }))
      if (!added.length) return sendJson(res, 200, { ok: false, error: note || '这几位都没写出理由，先不塞给你' })

      const main = [...f.main, ...added]
      feedCache = { ...f, main, moreCount: (f.moreCount || 0) + added.length }
      try { writeFileSync(feedFile, JSON.stringify(feedCache), 'utf8') } catch { /* 无所谓 */ }
      refreshStateDoc()
      logInfo('more:add', `${added.length} 条 / 池里还剩 ${queue.length - added.length}`)
      return sendJson(res, 200, { ok: true, main, added, left: queue.length - added.length, note })
    }

    // 桌宠头像：默认是蓝发鲸鱼女仆（来自 dsh-whale-widget，MIT）
    if (req.method === 'GET' && p === '/avatar') {
      try {
        const want = String(url.searchParams.get('p') || '')
        const chosen = AVATAR_PRESETS[want] ? want : (AVATAR_PRESETS[overrides.avatarPreset] ? overrides.avatarPreset : DEFAULT_AVATAR_PRESET)
        const own = join(stateDir, 'avatar.png')
        // ?p= 只看某个预设；不带参数时：自己上传过的优先，其次预设
        const file = want && AVATAR_PRESETS[want]
          ? join(PLUGIN_DIR, 'assets', AVATAR_PRESETS[want].file)
          : (existsSync(own) ? own : join(PLUGIN_DIR, 'assets', AVATAR_PRESETS[chosen].file))
        const buf = readFileSync(file)
        res.writeHead(200, {
          'content-type': 'image/png',
          // 换头像要立刻看到，别让浏览器缓存挡住
          'cache-control': 'no-cache',
          'content-length': buf.length,
        })
        res.end(buf)
        return
      } catch {
        return sendJson(res, 404, { ok: false, error: '没有头像文件' })
      }
    }

    if (req.method === 'GET' && p === '/explain') {
      const force = url.searchParams.get('force') === '1'
      const bvid = url.searchParams.get('bvid')
      if (bvid) {
        // 单条展开：写一段「为什么推荐」的话（比一句话长）
        const all = [...(feedCache?.main || []), ...(feedCache?.shortlist || []), ...(feedCache?.up || [])]
        const item = all.find((x) => x.bvid === bvid)
        if (!item) return sendJson(res, 404, { ok: false, error: '这条不在当前片单里' })
        const hit = reasons[bvid]
        if (hit?.long && !force) return sendJson(res, 200, { ok: true, bvid, long: hit.long, cached: true })
        const style = cfgNow().reasonStyle
        const c = cfgNow()
        const dur = Math.round((item.duration || 0) / 60)
        const system = [
          '你在替一个人解释「为什么把这条视频挑给他」。',
          '写 100–160 字的一段话：它讲了什么、对你有什么价值、适合什么时候看、有什么坑要提醒。',
          '具体、不吹、不用感叹号；不要复述标题；不要用「这条视频」开头。',
          style ? `语气与风格：${String(style).slice(0, 1500)}` : '语气与风格：像一个了解他口味的朋友。',
        ].join('\n')
        const user = [
          `标题：${item.title}`,
          `UP：${item.author}`,
          `时长：${dur} 分钟`,
          `分区：${item.typeName || '未知'}`,
          `tag：${(item.tags || []).join('、') || '（无）'}`,
          `数据：播放 ${item.play}，赞率 ${item.pct?.like ?? '?'}%，币率 ${item.pct?.coin ?? '?'}%，藏率 ${item.pct?.fav ?? '?'}%`,
          `命中的轴：${item.axis || ''}${item.sub ? ' · ' + item.sub : ''}`,
          item.why ? `一句话理由：${item.why}` : '',
        ].filter(Boolean).join('\n')
        const long = await writeReasonCore(ctx, {
          system, user, maxTokens: 400, timeoutMs: 45000,
          api: { base: c.apiBase, key: c.apiKey, model: c.apiModel },
        })
        if (long) {
          reasons[bvid] = { ...(reasons[bvid] || {}), long, at: Date.now() }
          saveReasonCache(reasonsFile, reasons)
        }
        return sendJson(res, 200, { ok: Boolean(long), bvid, long, cached: false })
      }
      const r = await getReasons(force)
      return sendJson(res, 200, r)
    }

    return sendJson(res, 404, { ok: false, error: `unknown ${req.method} ${p}` })
  }

  try {
    ctx.effect(() => ctx.webServer.register({
      kind: 'prefix',
      path: '/api/bili-jar',
      handler: async (req, res) => {
        try { await handle(req, res, new URL(req.url, 'http://127.0.0.1')) } catch (e) {
          sendJson(res, 500, { ok: false, error: e?.message ?? String(e) })
        }
      },
    }), 'bili-jar: /api/bili-jar 路由')
  } catch (e) {
    log(`HTTP 路由没挂上：${e?.message ?? e}`)
  }

  log(`已挂载（家=${stateDir}，版本=${version}，池=${prevPool.length}）`)
  refreshStateDoc()
}
